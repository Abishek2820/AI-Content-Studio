# app.py - Streamlit Frontend
import streamlit as st
import time
from content_engine import ContentEngine
from config import config

# ─── Page Config ──────────────────────────────────────────────
st.set_page_config(
    page_title="AI Content Studio",
    page_icon="✨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS ───────────────────────────────────────────────
st.markdown('''
<style>
    .main-header { font-size: 2.5rem; font-weight: 800; background: linear-gradient(90deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .sub-header { color: #888; font-size: 1.1rem; margin-bottom: 2rem; }
    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] { border-radius: 8px 8px 0 0; padding: 10px 20px; font-weight: 600; }
    .success-box { background: linear-gradient(135deg, #667eea20, #764ba220); border-left: 4px solid #667eea; padding: 1rem; border-radius: 8px; }
    .metric-card { background: #1e1e2e; padding: 1rem; border-radius: 12px; text-align: center; border: 1px solid #333; }
    .idea-card { background: #16162a; border: 1px solid #2a2a4a; border-radius: 12px; padding: 1.2rem; margin-bottom: 1rem; transition: all 0.3s; }
    .idea-card:hover { border-color: #667eea; transform: translateY(-2px); }
    .tag { display: inline-block; background: #667eea30; color: #a5b4fc; padding: 2px 10px; border-radius: 12px; font-size: 0.8rem; margin-right: 6px; }
    .stButton>button { border-radius: 8px; font-weight: 600; transition: all 0.3s; }
    .stButton>button:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
    div[data-testid="stSidebarUserContent"] { padding-top: 1rem; }
</style>
''', unsafe_allow_html=True)

# ─── Session State ────────────────────────────────────────────
if "generated_content" not in st.session_state:
    st.session_state.generated_content = ""
if "analysis_result" not in st.session_state:
    st.session_state.analysis_result = ""
if "history" not in st.session_state:
    st.session_state.history = []

# ─── Sidebar ──────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Settings")

    engine = ContentEngine()
    models = engine.client.list_models()
    selected_model = st.selectbox("🤖 Model", models, index=0)
    engine.client.model = selected_model

    st.divider()
    st.markdown("### 📊 Status")
    if engine.client.is_available():
        st.success("🟢 Ollama Connected")
    else:
        st.error("🔴 Ollama Offline")
        st.info("Run: `ollama serve` in terminal")

    st.divider()
    st.markdown("### 📚 History")
    for i, item in enumerate(st.session_state.history[-5:]):
        with st.expander(f"{item['type']}: {item['topic'][:30]}..."):
            st.caption(item['content'][:200] + "...")
            if st.button("Load", key=f"load_{i}"):
                st.session_state.generated_content = item['content']
                st.rerun()

# ─── Main Header ──────────────────────────────────────────────
st.markdown('<div class="main-header">✨ AI Content Studio</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Generate, Analyze & Optimize Content with Local AI</div>', unsafe_allow_html=True)

# ─── Tabs ─────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs(["📝 Content Generator", "🎬 Video Script", "🔍 Analyzer", "💡 Idea Generator", "🎬 AI Video Generator"])


# ─── TAB 1: Content Generator ─────────────────────────────────
with tab1:
    col1, col2 = st.columns([2, 3])

    with col1:
        st.markdown("### 🎯 Configuration")
        content_type = st.selectbox("Content Type", config.CONTENT_TYPES)
        topic = st.text_area("Topic / Prompt", placeholder="e.g., 10 Tips for Remote Work Productivity", height=80)
        tone = st.selectbox("Tone", config.TONES)
        length = st.segmented_control("Length", ["Short", "Medium", "Long"], default="Medium")
        extras = st.text_area("Extra Instructions (optional)", placeholder="e.g., Include statistics, add a call-to-action", height=60)

        generate_btn = st.button("🚀 Generate Content", type="primary", use_container_width=True)

    with col2:
        st.markdown("### 📄 Output")
        output_container = st.container()

        if generate_btn and topic:
            with st.spinner("✨ Crafting your content..."):
                result = engine.generate_content(content_type, topic, tone, length.lower(), extras)
                if result.get("success"):
                    st.session_state.generated_content = result["text"]
                    st.session_state.history.append({"type": content_type, "topic": topic, "content": result["text"]})
                else:
                    st.error(f"Error: {result.get('error')}")

        if st.session_state.generated_content:
            with output_container:
                st.markdown('<div class="success-box">', unsafe_allow_html=True)
                st.markdown(st.session_state.generated_content)
                st.markdown('</div>', unsafe_allow_html=True)

                c1, c2, c3 = st.columns(3)
                with c1:
                    st.download_button("📥 Download", st.session_state.generated_content, file_name="content.txt")
                with c2:
                    if st.button("📋 Copy"):
                        st.toast("Copied to clipboard!")
                with c3:
                    if st.button("🔍 Analyze This"):
                        st.session_state.analysis_content = st.session_state.generated_content
                        st.info("Switch to Analyzer tab!")

                # Regenerate with feedback
                st.divider()
                feedback = st.text_input("💬 Want changes? Describe what to modify:")
                if feedback and st.button("🔄 Regenerate", type="secondary"):
                    with st.spinner("Applying changes..."):
                        new_result = engine.regenerate_with_feedback(
                            st.session_state.generated_content, feedback, content_type
                        )
                        if new_result.get("success"):
                            st.session_state.generated_content = new_result["text"]
                            st.rerun()

# ─── TAB 2: Video Script ──────────────────────────────────────
with tab2:
    col1, col2 = st.columns([2, 3])

    with col1:
        st.markdown("### 🎬 Video Configuration")
        v_topic = st.text_area("Video Topic", placeholder="e.g., How to Start a YouTube Channel in 2024")
        v_style = st.selectbox("Video Style", config.VIDEO_STYLES)
        v_platform = st.selectbox("Platform", config.PLATFORMS)
        v_duration = st.slider("Duration (minutes)", 1, 20, 5)
        v_tone = st.selectbox("Tone", config.TONES, key="v_tone")
        v_extras = st.text_area("Extra Notes", placeholder="e.g., Mention our product at 2:30", key="v_extras")

        v_generate = st.button("🎬 Generate Script", type="primary", use_container_width=True, key="v_btn")

    with col2:
        st.markdown("### 📝 Script Output")
        if v_generate and v_topic:
            with st.spinner("🎥 Writing your script..."):
                v_result = engine.generate_video_script(v_topic, v_style, v_platform, v_duration, v_tone, v_extras)
                if v_result.get("success"):
                    st.markdown('<div class="success-box">', unsafe_allow_html=True)
                    st.markdown(v_result["text"])
                    st.markdown('</div>', unsafe_allow_html=True)
                    st.download_button("📥 Download Script", v_result["text"], file_name="video_script.txt")
                else:
                    st.error(f"Error: {v_result.get('error')}")

# ─── TAB 3: Analyzer ──────────────────────────────────────────
with tab3:
    col1, col2 = st.columns([2, 3])

    with col1:
        st.markdown("### 🔍 Content Analysis")
        analyze_text = st.text_area(
            "Paste content to analyze",
            value=st.session_state.get("analysis_content", ""),
            height=250,
            placeholder="Paste your blog post, script, or any content here..."
        )
        analyze_btn = st.button("🔬 Analyze", type="primary", use_container_width=True)

    with col2:
        st.markdown("### 📊 Analysis Report")
        if analyze_btn and analyze_text:
            with st.spinner("🔍 Deep analysis in progress..."):
                a_result = engine.analyze_content(analyze_text)
                if a_result.get("success"):
                    st.session_state.analysis_result = a_result["text"]
                    st.markdown('<div class="success-box">', unsafe_allow_html=True)
                    st.markdown(a_result["text"])
                    st.markdown('</div>', unsafe_allow_html=True)
                else:
                    st.error(f"Error: {a_result.get('error')}")

# ─── TAB 4: Idea Generator ────────────────────────────────────
with tab4:
    st.markdown("### 💡 Content Idea Generator")

    idea_col1, idea_col2, idea_col3 = st.columns([2, 1, 1])
    with idea_col1:
        niche = st.text_input("Enter your niche/topic", placeholder="e.g., Digital Marketing, Fitness, AI Tools")
    with idea_col2:
        idea_count = st.number_input("Count", min_value=1, max_value=10, value=5)
    with idea_col3:
        st.markdown("<br>", unsafe_allow_html=True)
        idea_btn = st.button("💡 Generate Ideas", type="primary", use_container_width=True)

    if idea_btn and niche:
        with st.spinner("💭 Brainstorming ideas..."):
            i_result = engine.generate_ideas(niche, idea_count)
            if i_result.get("success"):
                st.markdown(i_result["text"])
            else:
                st.error(f"Error: {i_result.get('error')}")

with tab5:
    st.markdown("### 🎬 AI Video Generator")
    st.info("⚡ This tab generates AI video prompts & production plans. Actual video creation uses free external tools.")
    
    from video_generator import VideoGenerator
    vgen = VideoGenerator()
    
    vid_col1, vid_col2 = st.columns([2, 3])
    
    with vid_col1:
        st.markdown("#### 🎥 Video Configuration")
        vid_topic = st.text_area("Video Topic/Concept", placeholder="e.g., A serene mountain sunrise with meditation music", height=60)
        vid_style = st.selectbox("Visual Style", ["Cinematic", "Animated", "Realistic", "Abstract", "Documentary", "Motion Graphics"], key="vid_style")
        vid_duration = st.slider("Duration (seconds)", 5, 60, 15, key="vid_dur")
        vid_tone = st.selectbox("Mood/Tone", ["Calm", "Energetic", "Dramatic", "Inspirational", "Mysterious", "Joyful"], key="vid_tone2")
        vid_platform = st.selectbox("Target Platform", ["YouTube Shorts", "TikTok", "Instagram Reels", "General"], key="vid_plat")
        vid_extras = st.text_area("Extra Details", placeholder="e.g., Include flying birds, slow motion water ripples", height=60, key="vid_extras2")
        
        st.divider()
        st.markdown("#### 🛠️ Generation Mode")
        gen_mode = st.radio("Choose mode:", [
            "📋 Full Production Plan (Text)", 
            "🖼️ Generate AI Frame (Image)",
            "📚 Free Tools Guide"
        ], key="vid_mode")
        
        vid_generate = st.button("🎬 Generate", type="primary", use_container_width=True, key="vid_btn2")
    
    with vid_col2:
        st.markdown("#### 📤 Output")
        
        if vid_generate and vid_topic:
            if gen_mode == "📋 Full Production Plan (Text)":
                with st.spinner("🎥 Creating production plan..."):
                    result = vgen.generate_video_plan(vid_topic, vid_style, vid_duration, vid_tone, vid_platform, vid_extras)
                    if result.get("success"):
                        st.markdown('<div class="success-box">', unsafe_allow_html=True)
                        st.markdown(result["text"])
                        st.markdown('</div>', unsafe_allow_html=True)
                        st.download_button("📥 Download Plan", result["text"], file_name="video_plan.txt", key="dl_plan")
                    else:
                        st.error(f"Error: {result.get('error')}")
            
            elif gen_mode == "🖼️ Generate AI Frame (Image)":
                with st.spinner("🎨 Generating AI frame..."):
                    ai_prompt = vgen.generate_video_prompt(vid_topic, vid_style, vid_duration, vid_tone, vid_extras)
                    if ai_prompt:
                        st.caption(f"**AI Prompt:** {ai_prompt[:200]}...")
                        
                        result = vgen.generate_with_pollinations(ai_prompt)
                        if result.get("success"):
                            st.image(result["data"], caption="AI Generated Frame", use_container_width=True)
                            st.success(result["message"])
                            
                            st.download_button(
                                "📥 Download Frame (PNG)", 
                                result["data"], 
                                file_name=f"ai_frame_{int(time.time())}.png",
                                mime="image/png",
                                key="dl_frame"
                            )
                            
                            st.info("💡 Generate 3-5 frames with different seeds, then use CapCut/FFmpeg to stitch into video!")
                        else:
                            st.error(f"Frame generation failed: {result.get('error')}")
                    else:
                        st.error("Failed to generate AI prompt. Check Ollama connection.")
            
            elif gen_mode == "📚 Free Tools Guide":
                st.markdown('<div class="success-box">', unsafe_allow_html=True)
                st.markdown(vgen.get_free_tools_guide())
                st.markdown('</div>', unsafe_allow_html=True)

# ─── Footer ───────────────────────────────────────────────────
st.divider()
st.caption("🔒 Powered by Ollama (Local AI) | No data leaves your machine")
