# config.py - Configuration & Constants
import os
from dataclasses import dataclass

@dataclass
class Config:
    OLLAMA_HOST: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    DEFAULT_MODEL: str = os.getenv("DEFAULT_MODEL", "llama3.2:1b")
    TEMPERATURE: float = 0.7
    MAX_TOKENS: int = 1024

    CONTENT_TYPES = ["Blog Post", "Social Media", "Video Script", "Marketing Copy", "Email", "Story"]
    TONES = ["Professional", "Casual", "Humorous", "Persuasive", "Inspirational", "Technical"]
    VIDEO_STYLES = ["Tutorial", "Vlog", "Review", "Explainer", "Storytelling", "Interview"]
    PLATFORMS = ["YouTube", "TikTok", "Instagram Reels", "LinkedIn", "Twitter/X"]

config = Config()