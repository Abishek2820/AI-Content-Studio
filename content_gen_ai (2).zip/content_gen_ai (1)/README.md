# ✨ AI Content Studio

A **Streamlit-powered content generation app** using **Ollama** (local open-source LLMs). Generate blogs, social posts, video scripts, analyze content, and get fresh ideas — all running locally on your machine.

---

## 📁 Folder Structure

```
content_gen_ai/
├── app.py              # Main Streamlit frontend (UI + interactions)
├── content_engine.py   # Content generation logic & prompts
├── ollama_client.py    # Ollama API wrapper
├── config.py           # Configuration & constants
├── requirements.txt    # Python dependencies
└── README.md           # This file
```

---

## 🚀 Quick Start

### 1. Install Ollama
```bash
# macOS/Linux
curl -fsSL https://ollama.com/install.sh | sh

# Or download from: https://ollama.com/download
```

### 2. Pull a Model
```bash
ollama pull llama3        # or mistral, phi3, gemma, etc.
```

### 3. Start Ollama Server
```bash
ollama serve
```

### 4. Install Dependencies
```bash
pip install -r requirements.txt
```

### 5. Run the App
```bash
streamlit run app.py
```

---

## 🎨 Features

| Feature | Description |
|---------|-------------|
| 📝 **Content Generator** | Blogs, social posts, emails, stories, marketing copy |
| 🎬 **Video Script Writer** | Scripts with hooks, scenes, B-roll, CTAs for any platform |
| 🔍 **Content Analyzer** | Strengths, weaknesses, SEO score, improvement ideas |
| 💡 **Idea Generator** | Fresh, trend-aware content ideas with outlines |
| 🔄 **Regenerate with Feedback** | Iterate and refine content based on your input |
| 📥 **Download** | Export generated content as `.txt` files |
| 🔒 **100% Local** | No API keys, no data leaves your machine |

---

## ⚙️ Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OLLAMA_HOST` | `http://localhost:11434` | Ollama server URL |
| `DEFAULT_MODEL` | `llama3` | Default LLM model |

---

## 🛠️ Tech Stack

- **Frontend**: Streamlit
- **AI Backend**: Ollama (Local LLMs)
- **Models**: Llama3, Mistral, Phi3, Gemma, etc.
- **Language**: Python 3.9+

---

## 📸 Screenshots

> Run the app and explore 4 tabs: Content Generator, Video Script, Analyzer, and Idea Generator.

---

## 📝 License

MIT License — free to use and modify.
