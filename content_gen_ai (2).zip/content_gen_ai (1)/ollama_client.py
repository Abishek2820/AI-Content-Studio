# ollama_client.py - Ollama API Wrapper
import requests
import json
from config import config

class OllamaClient:
    def __init__(self, host=None, model=None):
        self.host = host or config.OLLAMA_HOST
        self.model = model or config.DEFAULT_MODEL
    
    def generate(self, prompt, system="", stream=False):
        """Generate text from Ollama model"""
        payload = {
            "model": self.model,
            "prompt": prompt,
            "system": system,
            "stream": stream,
            "options": {"temperature": config.TEMPERATURE, "num_predict": config.MAX_TOKENS}
        }
        try:
            resp = requests.post(f"{self.host}/api/generate", json=payload, stream=stream)
            resp.raise_for_status()
            if stream:
                return resp
            data = resp.json()
            return {"success": True, "text": data.get("response", ""), "done": data.get("done", True)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_models(self):
        """List available Ollama models"""
        try:
            resp = requests.get(f"{self.host}/api/tags")
            resp.raise_for_status()
            models = resp.json().get("models", [])
            return [m["name"] for m in models]
        except Exception as e:
            return [config.DEFAULT_MODEL]
    
    def is_available(self):
        """Check if Ollama server is running"""
        try:
            requests.get(f"{self.host}/api/tags", timeout=3)
            return True
        except:
            return False