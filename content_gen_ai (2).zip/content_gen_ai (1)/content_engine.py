# content_engine.py - Content Generation Logic
from ollama_client import OllamaClient
from config import config

class ContentEngine:
    def __init__(self, model=None):
        self.client = OllamaClient(model=model)
    
    SYSTEM_PROMPTS = {
        "blog": "You are an expert content writer. Create engaging, well-structured blog posts with SEO optimization.",
        "social": "You are a social media strategist. Create viral, engaging posts with hashtags and emojis.",
        "video": "You are a professional video scriptwriter. Create compelling scripts with hooks, structure, and CTAs.",
        "marketing": "You are a conversion copywriter. Create persuasive marketing copy that drives action.",
        "email": "You are an email marketing expert. Create emails with strong subject lines and clear CTAs.",
        "story": "You are a creative storyteller. Craft immersive narratives with vivid descriptions."
    }
    
    def generate_content(self, content_type, topic, tone, length="medium", extras=""):
        """Generate written content based on parameters"""
        system = self.SYSTEM_PROMPTS.get(content_type.lower().split()[0], self.SYSTEM_PROMPTS["blog"])
        length_map = {"short": "200-300 words", "medium": "500-700 words", "long": "1000+ words"}
        word_count = length_map.get(length, "500-700 words")
        
        prompt = f"""Create a {tone.lower()} {content_type.lower()} about: {topic}
Length: {word_count}
{extras}

Provide the content directly without meta-commentary."""
        
        return self.client.generate(prompt, system=system)
    
    def generate_video_script(self, topic, style, platform, duration, tone, extras=""):
        """Generate video script with scene breakdown"""
        system = "You are a professional video producer and scriptwriter."
        
        prompt = f"""Create a detailed {duration}-minute {style.lower()} video script for {platform} about: {topic}
Tone: {tone}
{extras}

Format with:
- HOOK (0-5 sec)
- INTRO (5-15 sec)
- MAIN CONTENT (scenes with timestamps)
- OUTRO / CTA
- B-ROLL suggestions
- On-screen text suggestions

Be specific and actionable."""
        
        return self.client.generate(prompt, system=system)
    
    def analyze_content(self, content_text):
        """Analyze content and provide insights"""
        system = "You are a content strategy analyst. Provide actionable insights."
        
        prompt = f"""Analyze this content and provide:
1. **Strengths** - What's working well
2. **Weaknesses** - What needs improvement
3. **SEO Score** (1-10) with reasoning
4. **Engagement Prediction** (1-10)
5. **3 Improvement Ideas** - Specific actionable changes
6. **Target Audience** - Who this resonates with
7. **Tone Analysis** - Detected tone and consistency

Content to analyze:
{content_text[:3000]}"""
        
        return self.client.generate(prompt, system=system)
    
    def generate_ideas(self, niche, count=5, format_type="bullet"):
        """Generate content ideas for a niche"""
        system = "You are a creative content strategist. Generate unique, trending ideas."
        
        prompt = f"""Generate {count} fresh content ideas for the niche: {niche}

For each idea provide:
- **Title**
- **Format** (blog/video/social/email)
- **Hook/Angle** - Why it works
- **Target Emotion**
- **Estimated Engagement** (High/Med/Low)
- **Quick Outline** (3-5 points)

Make ideas unique, trend-aware, and actionable."""
        
        return self.client.generate(prompt, system=system)
    
    def regenerate_with_feedback(self, original, feedback, content_type):
        """Regenerate content based on user feedback"""
        system = self.SYSTEM_PROMPTS.get(content_type.lower().split()[0], self.SYSTEM_PROMPTS["blog"])
        
        prompt = f"""Original content:
{original}

User feedback / requested changes:
{feedback}

Please rewrite the content incorporating this feedback while maintaining quality and flow."""
        
        return self.client.generate(prompt, system=system)