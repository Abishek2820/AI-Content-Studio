# video_generator.py - AI Video Generation Engine
import requests
import json
import base64
import time
from config import config

class VideoGenerator:
    """Generate AI videos from text prompts using free/open-source APIs"""
    
    # Free/open-source video generation endpoints
    API_ENDPOINTS = {
        "pollinations": {
            "url": "https://image.pollinations.ai/prompt/{prompt}?width=1280&height=720&nologo=true&seed={seed}&enhance=true",
            "type": "image_sequence",
            "desc": "Free AI image → animate with free tools"
        },
        "replicate_svd": {
            "url": "https://replicate.com/stability-ai/stable-video-diffusion",
            "type": "api_key_required",
            "desc": "Stable Video Diffusion (needs free Replicate token)"
        },
        "huggingface_wan": {
            "url": "https://api-inference.huggingface.co/models/Wan-AI/Wan2.1-T2V-1.3B",
            "type": "hf_api",
            "desc": "Wan 2.1 Text-to-Video (free HF token)"
        }
    }
    
    def __init__(self):
        self.session = requests.Session()
    
    def generate_video_prompt(self, topic, style, duration, tone, extras=""):
        """Generate a detailed video generation prompt using Ollama"""
        from ollama_client import OllamaClient
        
        client = OllamaClient()
        system = "You are an expert AI video prompt engineer. Create detailed, vivid prompts for AI video generation models."
        
        prompt = f"""Create a detailed AI video generation prompt for:
Topic: {topic}
Style: {style}
Duration: {duration} seconds
Tone: {tone}
{extras}

Write a single, highly detailed paragraph (50-80 words) describing the exact visual scene. Include:
- Camera movements (pan, zoom, dolly, etc.)
- Lighting and atmosphere
- Character actions and expressions
- Background details
- Color palette and mood
- Specific visual effects

Format: Just the prompt text, no explanations."""
        
        result = client.generate(prompt, system=system)
        return result.get("text", "").strip() if result.get("success") else ""
    
    def generate_with_pollinations(self, prompt, seed=None):
        """Generate AI image/frames using Pollinations (completely free, no key)"""
        seed = seed or int(time.time())
        import urllib.parse
        encoded_prompt = urllib.parse.quote(prompt)
        url = self.API_ENDPOINTS["pollinations"]["url"].format(
            prompt=encoded_prompt, 
            seed=seed
        )
        
        try:
            resp = self.session.get(url, timeout=60)
            if resp.status_code == 200:
                return {
                    "success": True, 
                    "type": "image",
                    "url": url,
                    "data": resp.content,
                    "message": "AI frame generated! Use multiple frames + CapCut/FFmpeg to create video."
                }
            return {"success": False, "error": f"Status {resp.status_code}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def generate_video_plan(self, topic, style, duration, tone, platform, extras=""):
        """Generate a complete video production plan"""
        from ollama_client import OllamaClient
        
        client = OllamaClient()
        system = "You are a professional AI video producer. Create actionable production plans."
        
        prompt = f"""Create a detailed AI video production plan for:
Topic: {topic}
Style: {style}
Duration: {duration} seconds
Platform: {platform}
Tone: {tone}
{extras}

Provide:
1. **AI Video Prompt** (detailed visual description for image/video AI)
2. **Scene Breakdown** (3-5 key frames with timestamps)
3. **Frame Prompts** (individual AI image prompts for each scene)
4. **Voiceover Script** (narration text)
5. **Music/SFX Suggestions** (mood, genre, specific free sources)
6. **Editing Instructions** (transitions, effects, text overlays)
7. **Free Tools to Use** (CapCut, Canva, Clipchamp, etc.)
8. **Export Settings** (resolution, format for {platform})

Be specific and actionable."""
        
        return client.generate(prompt, system=system)
    
    def get_free_tools_guide(self):
        """Return guide for free video creation tools"""
        return ""